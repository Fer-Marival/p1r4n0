@extends('frontend.master')
@section('content')
<div class="clear"></div>
<div class="container" id="pirano">


<div class="col-md-6">
	<div class="tittle"> Il nostro segreto è l'amore</div>
	<em>Nuestros lentes son hechos con arte, tecnologia, pero el secreto es el <i>&hearts;</i>.</em>
	<ul>
		<li>100% POLARIZADOS</li>
		<li>MICAS PLANAS FASHION LOOK</li>
		<li>LA MODA ITALIANA EN TU CASA</li>
		<li>MEJOR PROTECCIÓN UVA/ UVB</li>
	</ul>
</div>
</div>
@endsection