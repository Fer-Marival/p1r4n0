<div class="bottom-bar">
	<div class="row align-items-center">
		<div class="col"><a href="https://api.whatsapp.com/send?phone=3221962051&text=Hola%20Me%20interesa%20tus%20Lentes%20como%20puedo%20comprar?"><i class="far fa-comment-alt"></i></a></div>
		<div class="col resalte"><a href="/shop"><i class="fas fa-shopping-cart"></i></a></div>
		<div class="col"><a href="mailto:info@pirano1913.com"><i class="far fa-envelope-open"></i></a></div>
	</div>
</div>